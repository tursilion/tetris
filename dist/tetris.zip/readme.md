20160103

Here's my version of Tetris! :)

Everyone knows how to play, but in case you're from Mars...

Shapes will fall from the top of the screen... use A and S to move them left or right, respectively. Press <enter> to rotate them, and
<space> to drop them (which makes them fall faster, a drop CAN be aborted with any keypress, unlike MOST cheap versions out there..). The idea is to make the shapes form a solid horizontal line. This line is removed from the screen. If your stack fills the entire box, you lose the game.

You can get up to four lines with a single drop (the so-called 'Tetris'). The more lines per drop you get, the more points it's worth.

This version has specific levels, each level has a set number of lines that you must finish to proceed. When you finish a level, you get bonus points for how low your remaining puzzle is, and the screen is cleared.

At level 11 you start getting an automatic handicap of random blocks in the lower half of the screen (the height increases). At level 21 random blocks will also appear as you drop bricks.

Press any key to begin a game. Press '1' to warp to level 11 after the first level, or '2' to warp to level 21. (Any other key warps to level 2 after level 1 <grin> )

As of 2016 I added the 'bag' concept rather than 100% randomness, but it's not tested. You'll need PCC to compile this, though it will probably port to other compilers and I intend to actually do so at some point...



